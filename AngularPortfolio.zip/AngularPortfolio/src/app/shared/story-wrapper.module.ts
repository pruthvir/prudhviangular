import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoryModule } from '../story/story.module';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoryModule
  ]
})
export class StoryWrapperModule { }

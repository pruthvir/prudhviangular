import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkModule } from '../work/work.module';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    WorkModule
  ]
})
export class WorkWrapperModule { }

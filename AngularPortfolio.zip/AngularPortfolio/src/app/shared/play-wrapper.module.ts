import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlayModule } from '../play/play.module';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PlayModule
  ]
})
export class PlayWrapperModule { }

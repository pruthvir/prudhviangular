import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PlayRoutingModule } from './play-routing.module';
import { PlayComponent } from './play.component';
import { AgmCoreModule } from '@agm/core';
// import { navbarComponent } from "./navbar";

@NgModule({
  imports: [
    CommonModule,
    PlayRoutingModule,
    AgmCoreModule
  ],
  declarations: [PlayComponent],
  providers: []
})
export class PlayModule {}
